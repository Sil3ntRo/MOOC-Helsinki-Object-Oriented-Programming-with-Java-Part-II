
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.*;
import static org.junit.Assert.*;

@Points("50")
public class PlaceholderTest {

    @Test
    public void allDone() {
        assertTrue(true);
    }

}
