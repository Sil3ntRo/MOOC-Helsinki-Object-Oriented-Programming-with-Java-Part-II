
public class Main {

    public static void main(String[] args) {
        System.out.println("" + 
                "Course is over!\n" + 
                "After you have submitted this exercise, remember to give us " + 
                "some feedback about this course\n");
    }
}
