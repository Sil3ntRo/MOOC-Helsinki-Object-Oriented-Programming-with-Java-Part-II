
package reader.criteria;

public interface Criterion {
    boolean complies(String line);
}
