package wormgame;

public class Exercise {

    public static final String ID = "49";
}
