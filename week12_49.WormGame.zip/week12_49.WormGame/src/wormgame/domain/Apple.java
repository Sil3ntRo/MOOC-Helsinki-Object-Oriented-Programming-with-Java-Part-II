/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wormgame.domain;

/**
 *
 * @author Rohan
 */
public class Apple extends Piece {
    public Apple(int x, int y) {
        super(x,y);
    }
}
