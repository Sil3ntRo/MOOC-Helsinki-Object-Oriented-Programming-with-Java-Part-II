package wormgame;

public enum Direction {

    UP, RIGHT, DOWN, LEFT;
}
